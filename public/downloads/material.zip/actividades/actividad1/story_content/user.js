function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Nli1vGnLOL":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

