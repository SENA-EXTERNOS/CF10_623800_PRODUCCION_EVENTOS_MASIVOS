function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6pvK7OMyTjR":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

